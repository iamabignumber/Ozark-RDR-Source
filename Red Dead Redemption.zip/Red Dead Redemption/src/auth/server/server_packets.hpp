#pragma once
#include "server_types.hpp"
#include "security/security.hpp"

namespace auth::server {
	void populateHeader(Request::Header* header, ePackets packet, int size);
	bool packetConnect();
	bool packetWelcome();
	bool packetGetTime();
	bool packetGetSignatures();
	bool packetHeartbeat();
	bool packetMetric(security::metrics::metric* metric, std::string info = "");
}