#include "server_packets.hpp"
#include "utils/log.hpp"
#include "utils/va.hpp"
#include "utils/utils.hpp"
#include "global/auth_vars.hpp"
#include "auth/crypto/crypto.hpp"
#include "auth/network_socket.hpp"
#include "menu/init.hpp"
#include <algorithm>

namespace auth::server {
	void populateHeader(Request::Header* Header, ePackets Packet, int Size) {
		Header->m_Magic = 'DOSB';
		Header->m_Size = Size;
		Header->m_Packet = Packet;
		Header->m_Cheat.m_Cheat = CHEAT_RED_DEAD_REDEMPTION_2;
		Header->m_Cheat.m_PTB = false;
		Header->m_Cheat.m_CheatVersion = MENU_VERSION_INTERNAL;

		memcpy(Header->m_HardwareID, global::auth::g_hwid, 0x40);
		memcpy(Header->m_AuthToken, global::auth::g_authToken, 0x20);

		Header->m_EncryptionKeys.m_XorKey = (uint8_t)(rand() % 256);
		utils::createRandomBytes(Header->m_EncryptionKeys.m_HardwareKey, 0x10);
		utils::createRandomBytes(Header->m_EncryptionKeys.m_TokenKey, 0x10);
		utils::createRandomBytes(Header->m_EncryptionKeys.m_RequestKey, 0x10);

		crypto::rc4(Header->m_EncryptionKeys.m_HardwareKey, 0x10, Header->m_HardwareID, sizeof(Header->m_HardwareID));
		crypto::rc4(Header->m_EncryptionKeys.m_TokenKey, 0x10, Header->m_AuthToken, sizeof(Header->m_AuthToken));
	}

	void encryptPayload(Request::Header* Header) {
		if (Header->m_Size > sizeof(Request::Header)) {
			crypto::rc4Modified(Header->m_EncryptionKeys.m_RequestKey, 0x10, (uint8_t*)Header, Header->m_Size, sizeof(Request::Header));
		}
	}

	bool packetConnect() {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		Request::PacketPing* PacketPing = utils::allocateMemoryType<Request::PacketPing>();
		populateHeader(PacketPing, PACKET_PING, sizeof(Request::PacketPing));
		Response::PacketPing* PacketPingResponse = utils::allocateMemoryType<Response::PacketPing>();

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketPing PacketPingBackup;
				memcpy(&PacketPingBackup, PacketPing, sizeof(PacketPingBackup));

				encryptPayload(PacketPing);
				customDev("Auth", "Sending PACKET_PING");

				Network.send(PacketPing, PacketPing->m_Size);
				Network.receive(&PacketPingBackup, PacketPingResponse, sizeof(Response::PacketPing), &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_PING");

				if (Success) {
					if (ReceivedBytes == sizeof(Response::PacketPing)) {
						if (PacketPingResponse->m_PingTest == 69) {
							free(PacketPing);
							free(PacketPingResponse);
							return true;
						} else {
							ErrorMsg = utils::va::va("PING failed security checks"_Protect);
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketPing->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketPing);
		free(PacketPingResponse);
		return false;
	}

	bool packetWelcome() {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		Request::PacketWelcome* PacketWelcome = utils::allocateMemoryType<Request::PacketWelcome>();
		populateHeader(PacketWelcome, PACKET_WELCOME, sizeof(Request::PacketWelcome));
		Response::PacketWelcome* PacketWelcomeResponse = utils::allocateMemoryType<Response::PacketWelcome>();

		memcpy(PacketWelcome->m_PasswordHash, utils::convertStringToBytes(utils::rot13(utils::rot13NumberReverse(global::auth::g_password))).data(), 0x40);
		memcpy(PacketWelcome->m_Username, global::auth::g_username.c_str(), global::auth::g_username.length());

		DWORD ComputerNameSize = sizeof(PacketWelcome->m_PCName);
		GetUserNameA(PacketWelcome->m_PCName, &ComputerNameSize);

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketWelcome PacketWelcomeBackup;
				memcpy(&PacketWelcomeBackup, PacketWelcome, sizeof(PacketWelcomeBackup));

				encryptPayload(PacketWelcome);
				customDev("Auth", "Sending PACKET_WELCOME");
				Network.send(PacketWelcome, PacketWelcome->m_Size);
				Network.receive(&PacketWelcomeBackup, PacketWelcomeResponse, sizeof(Response::PacketWelcome), &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_WELCOME");

				if (Success) {
					if (ReceivedBytes == sizeof(Response::PacketWelcome)) {
						memcpy(global::auth::g_authToken, PacketWelcomeResponse->m_AuthToken, 0x20);

						switch (PacketWelcomeResponse->m_ResponseStatus) {
							case RESPONSE_WELCOME_DISABLED_ACCOUNT:
								ErrorMsg = "This cheat is currently disabled. Check our Discord for more information"_Protect;
								break;

							case RESPONSE_WELCOME_NO_ACCOUNT:
								ErrorMsg = "Please check your credentials"_Protect;
								break;

							case RESPONSE_WELCOME_OUTDATED:
								ErrorMsg = "This cheat is outdated"_Protect;
								break;

							case RESPONSE_WELCOME_BANNED_ACCOUNT:
								ErrorMsg = "Your account is banned. Check the website for more information"_Protect;
								break;

							case RESPONSE_WELCOME_DISABLED:
								ErrorMsg = "Your account is disabled. Check the website for more information"_Protect;
								break;

							case RESPONSE_WELCOME_HWID_MISMATCH:
								ErrorMsg = "Your HWID doesn't match. Navigate to https://ozark.gg/account.php to reset your HWID. You are allowed one reset per 24 hours"_Protect;
								break;

							case RESPONSE_WELCOME_PTB_DISABLED:
								ErrorMsg = "PTB is currently disabled"_Protect;
								break;

							case RESPONSE_SUCCESS:
								global::auth::g_hasToken = true;
								free(PacketWelcome);
								free(PacketWelcomeResponse);
								return true;
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketWelcome->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketWelcome);
		free(PacketWelcomeResponse);
		return false;
	}

	bool packetGetTime() {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		Request::PacketGetTime* PacketGetTime = utils::allocateMemoryType<Request::PacketGetTime>();
		populateHeader(PacketGetTime, PACKET_GET_TIME, sizeof(Request::PacketGetTime));
		Response::PacketGetTime* PacketGetTimeResponse = utils::allocateMemoryType<Response::PacketGetTime>();

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketGetTime PacketGetTimeBackup;
				memcpy(&PacketGetTimeBackup, PacketGetTime, sizeof(PacketGetTimeBackup));

				encryptPayload(PacketGetTime);
				customDev("Auth", "Sending PACKET_GET_TIME");
				Network.send(PacketGetTime, PacketGetTime->m_Size);
				Network.receive(&PacketGetTimeBackup, PacketGetTimeResponse, sizeof(Response::PacketGetTime), &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_GET_TIME");

				if (Success) {
					if (ReceivedBytes == sizeof(Response::PacketGetTime)) {
#undef max
						global::auth::g_hasLifetime = PacketGetTimeResponse->m_SecondsLeft == std::numeric_limits<int>::max();
						global::auth::g_secondsLeft = PacketGetTimeResponse->m_SecondsLeft;

						switch (PacketGetTimeResponse->m_ResponseStatus) {
							case RESPONSE_ERROR:
								ErrorMsg = "An error occured getting your subscriptions"_Protect;
								break;

							case RESPONSE_SUCCESS:
								free(PacketGetTime);
								free(PacketGetTimeResponse);
								return true;
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketGetTime->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketGetTime);
		free(PacketGetTimeResponse);
		return false;
	}

	bool packetGetSignatureData(int Size) {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		uint32_t TotalSize = sizeof(Response::PacketGetSignatures) + Size;

		Request::PacketGetSignatures* PacketGetSignatures = utils::allocateMemoryType<Request::PacketGetSignatures>();
		populateHeader(PacketGetSignatures, PACKET_GET_SIGNATURES, sizeof(Request::PacketGetSignatures));
		Response::PacketGetSignatures* PacketGetSignaturesResponse = (Response::PacketGetSignatures*)malloc(TotalSize);

		PacketGetSignatures->m_SizeOnly = false;

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketGetSignatures PacketGetSignaturesBackup;
				memcpy(&PacketGetSignaturesBackup, PacketGetSignatures, sizeof(PacketGetSignaturesBackup));

				encryptPayload(PacketGetSignatures);
				customDev("Auth", "Sending PACKET_GET_SIGNATURES");
				Network.send(PacketGetSignatures, PacketGetSignatures->m_Size);
				Network.receive(&PacketGetSignaturesBackup, PacketGetSignaturesResponse, TotalSize, &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_GET_SIGNATURES");

				if (Success) {
					if (ReceivedBytes == TotalSize) {
						switch (PacketGetSignaturesResponse->m_ResponseStatus) {
							case RESPONSE_ERROR:
								ErrorMsg = "An error occured getting menu data (#2)"_Protect;
								break;

							case RESPONSE_SUCCESS:
								uint8_t* Data = new uint8_t[Size];
								memcpy(Data, (uint8_t*)PacketGetSignaturesResponse + sizeof(Response::PacketGetSignatures), Size);

								for (int i = 0; i < Size; i++) {
									Request::BaseSignature* Signature = (Request::BaseSignature*)((uint64_t)Data + i);

									std::string SignatureStr = utils::convertBytesToString(&Signature->m_Signature, Signature->m_SignatureLength, true);
									utils::replaceString(SignatureStr, "3F"_Protect, "?"_Protect);
									global::auth::g_signatures.insert(std::make_pair(Signature->m_Name, patternInfo(SignatureStr, Signature->m_Offset, Signature->m_Name, Signature->m_Important)));

									i += sizeof(Request::BaseSignature) + Signature->m_SignatureLength - 2;
								}

								memset(Data, 0, Size);
								delete[] Data;

								free(PacketGetSignatures);
								free(PacketGetSignaturesResponse);
								return true;
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketGetSignatures->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketGetSignatures);
		free(PacketGetSignaturesResponse);
		return false;
	}

	bool packetGetSignatures() {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		Request::PacketGetSignatures* PacketGetSignatures = utils::allocateMemoryType<Request::PacketGetSignatures>();
		populateHeader(PacketGetSignatures, PACKET_GET_SIGNATURES, sizeof(Request::PacketGetSignatures));
		Response::PacketGetSignaturesLength* PacketGetSignaturesResponse = utils::allocateMemoryType<Response::PacketGetSignaturesLength>();

		PacketGetSignatures->m_SizeOnly = true;

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketGetSignatures PacketGetSignaturesBackup;
				memcpy(&PacketGetSignaturesBackup, PacketGetSignatures, sizeof(PacketGetSignaturesBackup));

				encryptPayload(PacketGetSignatures);
				customDev("Auth", "Sending PACKET_GET_SIGNATURES_LENGTH");
				Network.send(PacketGetSignatures, PacketGetSignatures->m_Size);
				Network.receive(&PacketGetSignaturesBackup, PacketGetSignaturesResponse, sizeof(Response::PacketGetSignaturesLength), &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_GET_SIGNATURES_LENGTH");

				if (Success) {
					if (ReceivedBytes == sizeof(Response::PacketGetSignaturesLength)) {
						switch (PacketGetSignaturesResponse->m_ResponseStatus) {
							case RESPONSE_ERROR:
								ErrorMsg = "An error occured getting menu data (#1)"_Protect;
								break;

							case RESPONSE_SUCCESS:
								uint32_t Size = PacketGetSignaturesResponse->m_Length;
								free(PacketGetSignatures);
								free(PacketGetSignaturesResponse);
								return packetGetSignatureData(Size);
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketGetSignatures->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketGetSignatures);
		free(PacketGetSignaturesResponse);
		return false;
	}

	bool packetHeartbeat() {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		Request::PacketHeartbeat* PacketHeartbeat = utils::allocateMemoryType<Request::PacketHeartbeat>();
		populateHeader(PacketHeartbeat, PACKET_HEARTBEAT, sizeof(Request::PacketHeartbeat));
		Response::PacketHeartbeat* PacketHeartbeatResponse = utils::allocateMemoryType<Response::PacketHeartbeat>();

		strcpy(PacketHeartbeat->m_GameUsername, utils::rot13(global::auth::g_socialClubName).c_str());
		strcpy(PacketHeartbeat->m_GameBuild, utils::rot13(global::auth::g_build).c_str());

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketHeartbeat PacketHeartbeatBackup;
				memcpy(&PacketHeartbeatBackup, PacketHeartbeat, sizeof(PacketHeartbeatBackup));

				encryptPayload(PacketHeartbeat);
				customDev("Auth", "Sending PACKET_HEARTBEAT");
				Network.send(PacketHeartbeat, PacketHeartbeat->m_Size);
				Network.receive(&PacketHeartbeatBackup, PacketHeartbeatResponse, sizeof(Response::PacketHeartbeat), &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_HEARTBEAT");

				if (Success) {
					if (ReceivedBytes == sizeof(Response::PacketHeartbeat)) {
						switch (PacketHeartbeatResponse->m_ResponseStatus) {
							case RESPONSE_ERROR:
								ErrorMsg = "An error occured sending a heartbeat"_Protect;
								break;

							case RESPONSE_SUCCESS:
								global::auth::g_hasLifetime = PacketHeartbeatResponse->m_SecondsLeft == std::numeric_limits<int>::max();
								global::auth::g_secondsLeft = PacketHeartbeatResponse->m_SecondsLeft;

								if (PacketHeartbeatResponse->m_UpdateAvailable) {
									// TODO: HotSwap
								}

								free(PacketHeartbeat);
								free(PacketHeartbeatResponse);
								return true;
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketHeartbeat->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketHeartbeat);
		free(PacketHeartbeatResponse);
		return false;
	}

	bool packetMetric(security::metrics::metric* metric, std::string info) {
		if (!global::auth::g_hasToken) return true;

		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		Request::PacketMetric* PacketMetric = utils::allocateMemoryType<Request::PacketMetric>();
		populateHeader(PacketMetric, PACKET_METRIC, sizeof(Request::PacketMetric));
		Response::PacketMetric* PacketMetricResponse = utils::allocateMemoryType<Response::PacketMetric>();

		PacketMetric->m_MetricID = metric->getMetric();
		if (!info.empty()) {
			strcpy(PacketMetric->m_MetricInfo, info.c_str());
		}

		int ReceivedBytes = 0;
		bool Success; const char* ErrorMsg;

		netsocket::network Network;

		Network.create(&Success, &ErrorMsg);
		if (Success) {
			Network.connect(&Success, &ErrorMsg);
			if (Success) {
				Request::PacketMetric PacketMetricBackup;
				memcpy(&PacketMetricBackup, PacketMetric, sizeof(PacketMetricBackup));

				encryptPayload(PacketMetric);
				customDev("Auth", "Sending PACKET_METRIC");
				Network.send(PacketMetric, PacketMetric->m_Size);
				Network.receive(&PacketMetricBackup, PacketMetricResponse, sizeof(Response::PacketMetric), &ReceivedBytes, &Success, &ErrorMsg);
				customDev("Auth", "Received PACKET_METRIC");

				if (Success) {
					if (ReceivedBytes == sizeof(Response::PacketMetric)) {
						if (PacketMetricResponse->m_Processed) {
							if (PacketMetricResponse->m_Banned) {
								menu::getInit()->unload();
							}

							free(PacketMetric);
							free(PacketMetricResponse);
							return true;
						}
					} else {
						ErrorMsg = utils::va::va("Server didn't return enough data to pass security checks on %i"_Protect, PacketMetric->m_Packet);
					}
				}
			}
		}

		if (ErrorMsg) {
			customError("Auth"_Protect, ErrorMsg);
		}

		free(PacketMetric);
		free(PacketMetricResponse);
		return false;
	}
}