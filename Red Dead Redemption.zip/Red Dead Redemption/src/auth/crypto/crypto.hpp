#pragma once
#include "stdafx.hpp"

namespace crypto {
#define XECRYPT_SHA512_DIGEST_SIZE 64
#define XECRYPT_SHA512_BLOCK_SIZE 128

	typedef struct _XECRYPT_SHA512_STATE {
		DWORD count;
		uint64_t state[8];
		BYTE buffer[128];
	} XECRYPT_SHA512_STATE, * PXECRYPT_SHA512_STATE;

	void rc4(unsigned char* pbKey, unsigned int cbKey, unsigned char* pbInpOut, unsigned int cbInpOut, unsigned int startOffset = 0);
	void rc4Modified(uint8_t* pbKey, uint32_t cbKey, uint8_t* pbInpOut, uint32_t cbInpOut, uint32_t startOffset = 0);
	void sha512Init(XECRYPT_SHA512_STATE* pShaState);
	void sha512Update(XECRYPT_SHA512_STATE* pShaState, const BYTE* pbInp, DWORD cbInp);
	void sha512Final(XECRYPT_SHA512_STATE* pShaState, BYTE* pbOut, DWORD cbOut);

	std::string base64Decode(std::string source);
	std::string decryptAES(std::string message, std::string iv, int length);
}