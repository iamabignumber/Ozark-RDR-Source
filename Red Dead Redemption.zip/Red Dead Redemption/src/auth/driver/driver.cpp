#include "driver.hpp"
#include "auth/network_socket.hpp"
#include "utils/log.hpp"
#include "utils/utils.hpp"
#include "global/variables.hpp"

namespace auth::driver {
	bool packetWelcome() {
		if (!netsocket::network::initialize()) {
			customError("Auth"_Protect, "Failed to initialize"_Protect);
			return false;
		}

		request::packetWelcome* packetWelcome = utils::allocateMemoryType<request::packetWelcome>();
		response::packetWelcome* packetWelcomeResponse = utils::allocateMemoryType<response::packetWelcome>();

		packetWelcome->moduleBase = global::vars::g_menuAddress;
		packetWelcome->moduleSize = global::vars::g_menuSize;

		int receivedBytes = 0;
		bool success; const char* errorMsg;

		netsocket::network net;

		net.create(&success, &errorMsg);
		if (success) {
			BYTE ip[] = { 127, 0, 0, 1 };
			net.connect(&success, &errorMsg);
			if (success) {
				net.send(packetWelcome, sizeof(request::packetWelcome));
				net.receive(nullptr, packetWelcomeResponse, sizeof(response::packetWelcome), &receivedBytes, &success, &errorMsg);

				if (receivedBytes == 1) {
					if (packetWelcomeResponse->respCode == 69) {
						free(packetWelcome);
						free(packetWelcomeResponse);
						return true;
					}
				}
			}
		}

		if (errorMsg) {
			customError("Auth"_Protect, errorMsg);
		}

		free(packetWelcome);
		free(packetWelcomeResponse);
		return false;
	}
}