#pragma once
#include "driver_types.hpp"

namespace auth::driver {
	bool packetWelcome();
}