#pragma once
#include "stdafx.hpp"

namespace auth::driver {
	enum eResponseErrors {
		ERROR_READING_MAGIC,
		ERROR_INCORRECT_MAGIC,
		ERROR_READING_NEEDED_DATA,
		ERROR_READING_PACKET_BODY
	};

	enum ePackets {
		PACKET_WELCOME = 1,
		PACKET_IGNORE_NEXT_SCAN
	};

	namespace request {
		struct packetWelcome {
			uint64_t moduleBase;
			uint64_t moduleSize;
		};
	}

	namespace response {
		struct packetWelcome {
			BYTE respCode; // 69
		};
	}
}