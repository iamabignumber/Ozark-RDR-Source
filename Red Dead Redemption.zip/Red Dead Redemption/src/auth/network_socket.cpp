#include "network_socket.hpp"
#include "utils/log.hpp"
#include "utils/utils.hpp"
#include "crypto/crypto.hpp"
#include "global/auth_vars.hpp"

namespace netsocket {
	void DecryptKeys(auth::server::Response::EncryptionKeys* Keys) {
		for (int i = 0; i < 0x10; i++) {
			Keys->m_FirstKey[i] ^= 37;
			Keys->m_FirstKey[i] ^= Keys->m_XorKey;
			Keys->m_FirstKey[i] ^= 13;
			Keys->m_FirstKey[i] ^= Keys->m_FinalKey[i];
		}

		for (int i = 0; i < 0x10; i++) {
			Keys->m_SecondKey[i] ^= 69;
			Keys->m_SecondKey[i] ^= Keys->m_FinalKey[i];
			Keys->m_SecondKey[i] ^= 69;
			Keys->m_SecondKey[i] ^= Keys->m_XorKey;
		}
	}

	void DecryptHash(auth::server::Response::EncryptionKeys* Keys) {
		((uint8_t*)&Keys->m_Hash)[3] ^= Keys->m_XorKey;

		Keys->m_Hash ^= 420;
		Keys->m_Hash ^= 1337;

		for (int i = 0; i < 0x10; i++) {
			Keys->m_Hash ^= Keys->m_XorKey | Keys->m_FinalKey[i];
			Keys->m_Hash ^= Keys->m_XorKey ^ Keys->m_FinalKey[i];
			Keys->m_Hash ^= Keys->m_SecondKey[i];
			Keys->m_Hash ^= Keys->m_FirstKey[i] << 16;
		}
	}

	void DecryptPayload(auth::server::Request::Header* Header, uint8_t* Bytes, uint32_t Size, auth::server::Response::EncryptionKeys* Keys) {
		DecryptKeys(Keys);
		DecryptHash(Keys);

		// RC4 (Modified) buffer with m_RequestKey
		crypto::rc4Modified(Header->m_EncryptionKeys.m_RequestKey, sizeof(Header->m_EncryptionKeys.m_RequestKey), Bytes, Size);

		// RC4 buffer with m_FinalKey
		crypto::rc4(Keys->m_FinalKey, sizeof(Keys->m_FinalKey), Bytes, Size);

		// XOR each byte 4x times with each byte of unencrypted m_Hash
		std::vector<uint8_t> HashBytes = utils::convertNumberToBytes(Keys->m_Hash);
		for (uint32_t i = 0; i < Size; i++) {
			Bytes[i] ^= Keys->m_XorKey;

			for (int j = 0; j < 4; j++) {
				Bytes[i] ^= HashBytes[3 - j];
			}
		}

		// RC4 buffer with second 0x10 of m_AuthToken
		if (Header->m_Packet == auth::server::PACKET_PING) {
			// PACKET_PING wont have an auth token just yet
			uint8_t PingKey[16] = { 0x70, 0x65, 0x6E, 0x69, 0x73, 0x62, 0x69, 0x74, 0x63, 0x68, 0x67, 0x61, 0x67, 0x67, 0x6F, 0x74 };
			crypto::rc4(PingKey, 0x10, Bytes, Size);
		} else if (Header->m_Packet == auth::server::PACKET_WELCOME) {
			// PACKET_WELCOME wont have an auth token just yet
			uint8_t WelcomeKey[16] = { 0x68, 0x61, 0x68, 0x61, 0x20, 0x6C, 0x75, 0x6E, 0x61, 0x20, 0x67, 0x6F, 0x20, 0x62, 0x72, 0x72 };
			crypto::rc4(WelcomeKey, 0x10, Bytes, Size);
		} else {
			crypto::rc4(Header->m_EncryptionKeys.m_TokenKey, 0x10, Header->m_AuthToken, sizeof(Header->m_AuthToken));
			crypto::rc4(Header->m_AuthToken + 0x10, 0x10, Bytes, Size);
			crypto::rc4(Header->m_EncryptionKeys.m_TokenKey, 0x10, Header->m_AuthToken, sizeof(Header->m_AuthToken));
		}

		// XOR buffer with random key
		for (uint32_t i = 0; i < Size; i++) {
			Bytes[i] ^= Keys->m_XorKey;
		}
	}


	bool network::initialize() {
		static bool initialized = false;
		if (initialized) return initialized;

		WSADATA wsaData;
		if (WSAStartup(MAKEWORD(2, 2), &wsaData)) return false;
		
		initialized = true;
		return true;
	}

	network& network::create(bool* successful, const char** error) {
		bool success = true;

		for (int i = 0; i < 10; i++) {
			socketHandle = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
			if (socketHandle == SOCKET_ERROR) {
				success = false;
				customWarn("Network"_Protect, "Failed to create connection (#1), attempt %i to reconect. Status: %X"_Protect, i + 1, GetLastError());
			} else {
				success = true;
				break;
			}

			Sleep(100);
		}

		if (!success) {
			if (successful) *successful = false;
			if (error) *error = "Failed to maintain a connection after 10 tries (#1)"_Protect;
			return *this;
		}

		if (successful) *successful = true;
		return *this;
	}

	network& network::connect(bool* pSuccessful, const char** pError) {
		int sendRecvSize = 0x100000;
		setsockopt(socketHandle, SOL_SOCKET, SO_SNDBUF | SO_RCVBUF, (const char*)&sendRecvSize, sizeof(sendRecvSize));

		int timeout = SOCKET_TIMEOUT;
		setsockopt(socketHandle, SOL_SOCKET, SO_SNDTIMEO | SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));

		sockaddr_in addr;
		addr.sin_family = AF_INET;
		addr.sin_port = htons(6969);

		/*addr.sin_addr.S_un.S_un_b.s_b1 = 209;
		addr.sin_addr.S_un.S_un_b.s_b2 = 141;
		addr.sin_addr.S_un.S_un_b.s_b3 = 39;
		addr.sin_addr.S_un.S_un_b.s_b4 = 192;*/

		addr.sin_addr.S_un.S_un_b.s_b1 = 209;
		addr.sin_addr.S_un.S_un_b.s_b2 = 141;
		addr.sin_addr.S_un.S_un_b.s_b3 = 50;
		addr.sin_addr.S_un.S_un_b.s_b4 = 21;

		bool success = true;
		for (int i = 0; i < 10; i++) {
			if (::connect(socketHandle, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
				success = false;
				customWarn("Network"_Protect, "Failed to create connection (#2), attempt %i to reconect. Status: %X"_Protect, i + 1, GetLastError());
			} else {
				success = true;
				break;
			}

			Sleep(100);
		}

		if (!success) {
			closesocket(socketHandle);
			if (pSuccessful) *pSuccessful = false;
			if (pError) *pError = "Failed to maintain a connection after 10 tries (#2)"_Protect;
			return *this;
		}

		customDev("Network", "Connected to SERVER_MAIN (%i.%i.%i.%i)", addr.sin_addr.S_un.S_un_b.s_b1, addr.sin_addr.S_un.S_un_b.s_b2, addr.sin_addr.S_un.S_un_b.s_b3, addr.sin_addr.S_un.S_un_b.s_b4);

		if (pSuccessful) *pSuccessful = true;
		return *this;
	}

	network& network::send(void* buffer, int size) {
		char* currentData = (char*)buffer;
		int dataLeft = size;

		while (dataLeft > 0) {
			int sendStatus = ::send(socketHandle, currentData, min(2048, dataLeft), 0);
			if (sendStatus == SOCKET_ERROR) break;

			currentData += sendStatus;
			dataLeft -= sendStatus;
		}

		return *this;
	}

	network& network::receive(auth::server::Request::Header* header, void* pRecvBuffer, int size, int* pReadBytes, bool* pSuccessful, const char** pError) {
		char* receivedBuffer = new char[size];
		int remaining = size;
		int received = 0;

		while (remaining > 0) {
			int receive = ::recv(socketHandle, (char*)receivedBuffer + received, min(2048, remaining), 0);

			if (receive == SOCKET_ERROR) {
				if (pSuccessful) *pSuccessful = false;
				if (pError) *pError = "Failed receiving payload from server"_Protect;
				closesocket(socketHandle);
				delete[] receivedBuffer;
				return *this;
			}

			remaining -= receive;
			received += receive;

			if (receive == 0) break;
		}

		closesocket(socketHandle);

		if (pReadBytes) *pReadBytes = received;
		if (pSuccessful) *pSuccessful = true;

		if (received == 5) {
			if (*(int*)((uint64_t)receivedBuffer) == 0x13371337) {
				switch (*(BYTE*)((uint64_t)receivedBuffer + 4)) {
					case auth::server::ERROR_CANT_READ_MAGIC:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to read magic"_Protect;
						break;

					case auth::server::ERROR_INVALID_MAGIC:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to verify magic"_Protect;
						break;

					case auth::server::ERROR_CANT_READ_REQUIRED_HEADER:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to read header"_Protect;
						break;

					case auth::server::ERROR_INVALID_SIZE:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to verify size"_Protect;
						break;

					case auth::server::ERROR_INVALID_PACKET:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to verify packet"_Protect;
						break;

					case auth::server::ERROR_INVALID_CHEAT:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to verify cheat"_Protect;
						break;

					case auth::server::ERROR_CANT_READ_HEADER_DATA:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to read data"_Protect;
						break;

					case auth::server::ERROR_INVALID_PACKET_SIZE:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to verify packet size"_Protect;
						break;

					case auth::server::ERROR_AUTH_TOKEN_NOT_FOUND:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to verify auth token"_Protect;
						break;

					case auth::server::ERROR_ALLOCATING_MEMORY:
						if (pSuccessful) *pSuccessful = false;
						if (pError) *pError = "Failed to allocate server memory for request (ouch)"_Protect;
						break;
				}
				
				delete[] receivedBuffer;
				return *this;
			}
		}

		if (received > sizeof(auth::server::Response::EncryptionKeys)) {
			auth::server::Response::EncryptionKeys* Keys = (auth::server::Response::EncryptionKeys*)receivedBuffer;
			char* NewBytes = receivedBuffer + sizeof(auth::server::Response::EncryptionKeys);
			int NewSize = size - sizeof(auth::server::Response::EncryptionKeys);

			DecryptPayload(header, (uint8_t*)NewBytes, NewSize, Keys);
			memcpy((void*)((uint64_t)pRecvBuffer + sizeof(auth::server::Response::EncryptionKeys)), NewBytes, NewSize);
		} else {
			if (pError) *pError = "Failed to receive full payload from server"_Protect;
			if (pSuccessful) *pSuccessful = false;
		}

		delete[] receivedBuffer;
		return *this;
	}
}