#pragma once
#include "stdafx.hpp"
#include "server/server_types.hpp"

namespace netsocket {
#define SOCKET_TIMEOUT 20000

	class network {
	public:
		static bool initialize();

		__declspec(noinline) network& create(bool* pSuccessful, const char** pError);
		__declspec(noinline) network& connect(bool* pSuccessful, const char** pError);
		__declspec(noinline) network& send(void* buffer, int size);
		__declspec(noinline) network& receive(auth::server::Request::Header* header, void* pRecvBuffer, int size, int* pReadBytes, bool* pSuccessful, const char** pError);
	private:
		sockaddr_in serverHandle;
		SOCKET socketHandle;
	};
}