#pragma once
#include "stdafx.hpp"

namespace rage::events {
	
}