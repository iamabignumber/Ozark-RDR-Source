#include "auth_vars.hpp"

namespace global::auth {
	bool g_hasToken;
	BYTE g_authToken[0x20];
	BYTE g_hwid[64];
	std::unordered_map<std::string, patternInfo> g_signatures;
	std::string g_username;
	std::string g_password;
	std::string g_socialClubName;
	std::string g_socialClubEmail;
	std::string g_build;
	std::string g_presence;
	uint64_t g_rockstarId;
	uint32_t g_secondsLeft;
	bool g_hasLifetime;
	int g_treasureChestSpawnCount;
	int g_secondsInMP;
}