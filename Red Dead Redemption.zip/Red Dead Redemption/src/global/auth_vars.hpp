#pragma once
#include "stdafx.hpp"

struct patternInfo {
	std::string pattern;
	int offset;
	std::string name;
	bool important;

	patternInfo()
		: pattern(""), offset(0), name(""), important(false)
	{}

	patternInfo(std::string p, int o, std::string n, bool b = false)
		: pattern(p), offset(o), name(n), important(b)
	{}

	void reset() {
		for (std::size_t i = 0; i < pattern.length(); i++) pattern[i] = 'F';
		for (std::size_t i = 0; i < name.length(); i++) name[i] = 'F';

		pattern.clear();
		name.clear();
		offset = -1;
		important = false;
	}
};

namespace global::auth {
	extern bool g_hasToken;
	extern BYTE g_hwid[64];
	extern BYTE g_authToken[0x20];
	extern std::unordered_map<std::string, patternInfo> g_signatures;
	extern std::string g_username;
	extern std::string g_password;
	extern std::string g_socialClubName;
	extern std::string g_socialClubEmail;
	extern std::string g_build;
	extern std::string g_presence;
	extern uint64_t g_rockstarId;
	extern uint32_t g_secondsLeft;
	extern bool g_hasLifetime;
	extern int g_treasureChestSpawnCount;
	extern int g_secondsInMP;
}