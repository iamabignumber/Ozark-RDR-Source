#pragma once
#include "stdafx.hpp"
#include "security/security.hpp"

namespace auth {
	class authentication {
	public:
		bool run();
		bool heartbeat();
		void processCachedMetrics();
		void processMetric(security::metrics::metric* pMetric, std::string info = "");
	}; authentication* getAuth();
}