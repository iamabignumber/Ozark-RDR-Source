#include "auth.hpp"
#include "utils/utils.hpp"
#include "utils/json.hpp"
#include "utils/config.hpp"
#include "utils/log.hpp"
#include "global/auth_vars.hpp"
#include "auth/server/server_packets.hpp"
#include "utils/wmi.hpp"
#include "utils/va.hpp"
#include "auth/crypto/crypto.hpp"
#include <filesystem>
#include "auth/http/win_http_client.hpp"

namespace auth {
	LONG GetStringRegKey(HKEY hKey, const std::string& strValueName, std::string& strValue, const std::string& strDefaultValue) {
		strValue = strDefaultValue;
		CHAR szBuffer[512];
		DWORD dwBufferSize = sizeof(szBuffer);
		ULONG nError;
		nError = RegQueryValueExA(hKey, strValueName.c_str(), 0, NULL, (LPBYTE)szBuffer, &dwBufferSize);

		if (ERROR_SUCCESS == nError) {
			strValue = szBuffer;
		}

		return nError;
	}

	bool authentication::run() {
		if (wmi::initialize()) {
			std::string str = wmi::getData("Win32_OperatingSystem"_Protect, "Manufacturer"_Protect);
			str += wmi::getData("Win32_OperatingSystem"_Protect, "OSArchitecture"_Protect);
			str += wmi::getData("Win32_OperatingSystem"_Protect, "SerialNumber"_Protect);
			str += wmi::getData("Win32_OperatingSystem"_Protect, "SystemDrive"_Protect);
			str += wmi::getData("Win32_OperatingSystem"_Protect, "WindowsDirectory"_Protect);
			str += wmi::getData("Win32_ComputerSystem"_Protect, "Model"_Protect);
			str += wmi::getData("Win32_ComputerSystem"_Protect, "Manufacturer"_Protect);
			str += wmi::getData("Win32_BIOS"_Protect, "Manufacturer"_Protect);
			str += wmi::getData("Win32_Processor"_Protect, "Name"_Protect);

			crypto::XECRYPT_SHA512_STATE state;
			crypto::sha512Init(&state);
			crypto::sha512Update(&state, (BYTE*)str.data(), (DWORD)str.length());
			crypto::sha512Final(&state, global::auth::g_hwid, 64);

			str.clear();
			wmi::cleanup();
		} else {
			customError("Auth"_Protect, "Failed to initialize hardware"_Protect);
			return false;
		}

		if (std::filesystem::exists(utils::getConfig()->getAuthPath())) {
			std::ifstream InputAuthConfig(utils::getConfig()->getAuthPath());
			if (InputAuthConfig.good()) {
				nlohmann::json Temp;
				InputAuthConfig >> Temp;
				InputAuthConfig.close();

				global::auth::g_username = Temp["username"_Protect].get<std::string>();
				global::auth::g_password = Temp["password"_Protect].get<std::string>();

				uint8_t Hash[64];

				crypto::XECRYPT_SHA512_STATE State;
				crypto::sha512Init(&State);
				crypto::sha512Update(&State, (uint8_t*)global::auth::g_password.data(), (uint32_t)global::auth::g_password.length());
				crypto::sha512Final(&State, Hash, 64);

				global::auth::g_password = utils::rot13(utils::rot13Number(utils::convertBytesToString(Hash, 64)));
			} else {
				customError("Auth"_Protect, "Failed to open Ozark.auth"_Protect);
			}
		} else {
			HKEY hKey;
			LONG lRes = RegOpenKeyExW(HKEY_CURRENT_USER, L"SOFTWARE\\Ozark", 0, KEY_READ, &hKey);
			if (lRes == ERROR_SUCCESS) {
				if (GetStringRegKey(hKey, "Username", global::auth::g_username, "") == ERROR_SUCCESS) {
					std::string Password = "";
					if (GetStringRegKey(hKey, "Password", Password, "") == ERROR_SUCCESS) {
						global::auth::g_username = utils::rot13(crypto::decryptAES(crypto::base64Decode(global::auth::g_username), "ahfgcbfhghghtydh"_Protect, 0));
						Password = utils::rot13(crypto::decryptAES(crypto::base64Decode(Password), "ahfgcbfhghghtydh"_Protect, 0));

						uint8_t Hash[64];

						crypto::XECRYPT_SHA512_STATE State;
						crypto::sha512Init(&State);
						crypto::sha512Update(&State, (uint8_t*)Password.data(), (uint32_t)Password.length());
						crypto::sha512Final(&State, Hash, 64);

						global::auth::g_password = utils::rot13(utils::rot13Number(utils::convertBytesToString(Hash, 64)));
						goto Auth;
					}
				}

				customError("Auth"_Protect, "Failed to extract credentials from registry"_Protect);
				return false;
			}

			customError("Auth"_Protect, "Failed to find credentials in registry"_Protect);
			return false;
		}

	Auth:
		if (auth::server::packetConnect()) {
			if (auth::server::packetWelcome()) {
				if (auth::server::packetGetTime()) {
					if (auth::server::packetGetSignatures()) {
						customSuccess("Auth"_Protect, "Successfully passed all authentication stages"_Protect);
						return true;
					}
				}
			}
		}

		return false;
	}

	bool authentication::heartbeat() {
		return auth::server::packetHeartbeat();
	}

	void authentication::processCachedMetrics() {
		std::vector<std::string> cachedMetrics = utils::getConfig()->getFilesInDirectory(utils::getConfig()->getTempPath(), ".Ozark"_Protect);
		if (cachedMetrics.size()) {
			for (auto& metric : cachedMetrics) {
				auto filePath = utils::va::va("%s%s.Ozark"_Protect, utils::getConfig()->getTempPath(), metric.c_str());
				if (std::filesystem::file_size(filePath) == 204) {
					BYTE fileBytes[204];
					FILE* fp = fopen(filePath, "rb"_Protect);
					if (fp) {
						fread(fileBytes, 1, sizeof(fileBytes), fp);
						fclose(fp);
						remove(filePath);

						for (int i = 0; i < sizeof(fileBytes); i++) {
							fileBytes[i] ^= 0x69;
						}

						char info[200];
						memcpy(info, fileBytes + 4, 200);

						switch (*(security::metrics::eMetrics*)(fileBytes)) {
							case security::metrics::METRIC_INFO: break; // don't process, we don't care about these
							case security::metrics::METRIC_CLIENT_CRASH: break; // don't process, we don't care about these
							case security::metrics::METRIC_BLACKLISTED_PROCESS: break;  // don't process, we don't care about these

							case security::metrics::METRIC_DEBUGGER:
								processMetric(new security::metrics::metricDebugger(), info);
								break;
							case security::metrics::METRIC_THREAD_DEBUGGER:
								processMetric(new security::metrics::metricThreadDebugger(), info);
								break;
							case security::metrics::METRIC_INTEGRITY_CHECK_FAILED:
								processMetric(new security::metrics::metricIntegrityCheckFailed(), info);
								break;
							case security::metrics::METRIC_MODULE_DIGEST_MISMATCH:
								processMetric(new security::metrics::metricModuleDigestMismatch(), info);
								break;
						}
					}
				}
			}
		}
	}

	void authentication::processMetric(security::metrics::metric* pMetric, std::string info) {
		delete pMetric;
		return;

		if (pMetric->getMetric() != security::metrics::METRIC_INFO) {
			customError("S"_Protect, "Processing %i"_Protect, pMetric->getMetric());
		}

		if (!auth::server::packetMetric(pMetric, info)) {
			BYTE data[204];
			memset(data, 0, sizeof(data));

			*(int*)data = pMetric->getMetric();
			memcpy(data + 4, info.c_str(), info.length());

			for (int i = 0; i < sizeof(data); i++) {
				data[i] ^= 0x69;
			}

			FILE* file = fopen(utils::va::va("%s%s.Ozark"_Protect, utils::getConfig()->getTempPath(), utils::createRandomString(10)), "wb"_Protect);
			if (file) {
				fwrite(data, sizeof(char), sizeof(data), file);
				fclose(file);
			}

			security::getSecurity()->closeProcess();
		}

		pMetric->onEvent();
		delete pMetric;
	}

	authentication* getAuth() {
		static authentication instance;
		return &instance;
	}
}