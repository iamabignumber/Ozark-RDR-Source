#include "option.hpp"

void option::render(int pos) {}
void option::renderSelected(int pos, std::string submenuName) {}